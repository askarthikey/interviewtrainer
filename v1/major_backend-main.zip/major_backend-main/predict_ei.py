from fer import FER
import cv2

emotion_to_ei = {
    "happy": 1,
    "neutral": 1,
    "sad": 0,
    "angry": 0,
    "fear": 0,
    "disgust": 0,
    "surprise": 1
}

def predict_emotional_intelligence_fer(image_path, confidence_threshold=0.5, sad_threshold=0.3):
    try:
        detector = FER(mtcnn=True)
        img = cv2.imread(image_path)
        if img is None:
            return "unknown", 0
        emotion, confidence = detector.top_emotion(img)
        if not emotion:
            return "unknown", 0
        if emotion == "sad" and confidence >= sad_threshold:
            pass
        elif confidence < confidence_threshold:
            return emotion, 0
        return emotion, emotion_to_ei.get(emotion, 0)
    except Exception as e:
        print("FER error:", str(e))
        return "unknown", 0
