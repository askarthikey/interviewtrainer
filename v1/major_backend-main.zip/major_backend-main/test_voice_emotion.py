from transformers import pipeline
import whisper

# Load Whisper model for transcription
whisper_model = whisper.load_model("base")

# Load emotion classification pipeline
emotion_pipeline = pipeline("text-classification", model="j-hartmann/emotion-english-distilroberta-base", return_all_scores=True)

# Transcribe audio
audio_path = "uploads/audio.wav"
print("\n🔍 Transcribing...")
result = whisper_model.transcribe(audio_path, fp16=False)
transcript = result["text"].strip()
print(f"\n📝 Transcript:\n{transcript}")

# Analyze emotion from text
print("\n🔬 Analyzing Emotion...")
emotions = emotion_pipeline(transcript)[0]
emotions_sorted = sorted(emotions, key=lambda x: x['score'], reverse=True)
top_emotion = emotions_sorted[0]

# Output
print(f"\n🎭 Predicted Emotion: {top_emotion['label']}")
print(f"📊 Confidence: {round(top_emotion['score'], 3)}")
print("\n📋 All Emotion Scores:")
for e in emotions_sorted:
    print(f" - {e['label']}: {round(e['score'], 3)}")
