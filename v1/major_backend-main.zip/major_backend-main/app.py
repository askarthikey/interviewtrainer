from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import json
import time
import cv2
import torch
import numpy as np
import soundfile as sf
import whisper
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline
from predict_ei import predict_emotional_intelligence_fer

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads/'
RESULTS_FOLDER = 'results/'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

# Device setup
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Device set to use {device}")

# Whisper model
whisper_model = whisper.load_model("base")

# Voice emotion classification model (text-based)
text_model_name = "j-hartmann/emotion-english-distilroberta-base"
text_emotion_model = AutoModelForSequenceClassification.from_pretrained(text_model_name)
text_tokenizer = AutoTokenizer.from_pretrained(text_model_name)
text_emotion_pipeline = pipeline("text-classification", model=text_emotion_model, tokenizer=text_tokenizer, return_all_scores=True)

# Emotion labels considered positive
positive_emotions = {"joy", "surprise", "neutral", "calm", "happy"}

def extract_audio(video_path):
    audio_path = os.path.join(UPLOAD_FOLDER, "temp_audio.wav")
    os.system(f"ffmpeg -i {video_path} -ac 1 -ar 16000 -vn {audio_path} -y")
    return audio_path

def transcribe_audio(audio_path):
    print("\n--- Spoken Words (Transcription) ---")
    result = whisper_model.transcribe(audio_path, fp16=False)
    text = result["text"].strip()
    print(text)
    print("------------------------------------\n")
    return text

def predict_voice_emotion_from_text(transcribed_text):
    results = text_emotion_pipeline(transcribed_text)[0]
    sorted_results = sorted(results, key=lambda x: x['score'], reverse=True)
    emotion = sorted_results[0]['label'].lower()
    confidence = sorted_results[0]['score']
    ei_score = 1 if emotion in positive_emotions else 0
    print(f"Voice Emotion: {emotion}, Confidence: {round(confidence, 2)}, EI Score: {ei_score}")
    return emotion, confidence, ei_score

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'video' not in request.files:
        return jsonify({"error": "No video uploaded"}), 400

    video = request.files['video']
    video_path = os.path.join(UPLOAD_FOLDER, "interview.webm")

    video.save(video_path)

    # Convert for OpenCV
    converted_path = os.path.join(UPLOAD_FOLDER, "interview_converted.avi")
    os.system(f"ffmpeg -i {video_path} -vcodec mjpeg -acodec pcm_s16le {converted_path} -y")

    # Frame-by-frame face emotion analysis
    cap = cv2.VideoCapture(converted_path)
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    interval = fps

    face_scores = []
    emotions = []
    frame_data = []

    print("\nFrame-by-frame Face Emotion Analysis:")
    for i in range(0, total_frames, interval):
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ret, frame = cap.read()
        if not ret or frame is None:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        if gray.mean() < 30:
            continue
        temp_img = os.path.join(UPLOAD_FOLDER, f"frame_{i}.jpg")
        cv2.imwrite(temp_img, frame)
        emotion, ei_score = predict_emotional_intelligence_fer(temp_img)
        emotions.append(emotion)
        face_scores.append(ei_score)
        frame_data.append({"frame": i, "emotion": emotion})
        print(f"Frame {i}: Detected Emotion = {emotion}, EI Score = {ei_score}")
    cap.release()

    most_common_emotion = max(set(emotions), key=emotions.count) if emotions else "unknown"
    avg_face_ei = round(sum(face_scores) / len(face_scores), 2) if face_scores else 0.0

    # Voice Emotion (from transcription)
    audio_path = extract_audio(video_path)
    transcribed_text = transcribe_audio(audio_path)
    voice_emotion, voice_conf, voice_ei = predict_voice_emotion_from_text(transcribed_text)

    # Final EI
    final_score = round((avg_face_ei + voice_ei) / 2, 2)

    result = {
        "emotional_intelligence": {
            "detected_emotion": most_common_emotion,
            "emotional_intelligence_score": avg_face_ei
        },
        "voice_analysis": {
            "detected_emotion": voice_emotion,
            "confidence": round(voice_conf, 2),
            "voice_ei_score": voice_ei,
            "transcription": transcribed_text
        },
        "final_ei_score": final_score,
        "face_frame_data": frame_data
    }

    # Save result
    timestamp = int(time.time())
    result_file = f"results_{timestamp}.json"
    with open(os.path.join(RESULTS_FOLDER, result_file), "w") as f:
        json.dump(result, f)

    return jsonify({"result_file": result_file, "results": result})

@app.route('/results/<filename>', methods=['GET'])
def get_results(filename):
    return send_from_directory(RESULTS_FOLDER, filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
