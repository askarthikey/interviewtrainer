import React, { useEffect, useState } from "react";
import Navbar from "./Navbar";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import { useNavigate } from "react-router-dom";

const emotionMap = {
  happy: 3,
  neutral: 2,
  sad: 1,
  angry: 1,
  fear: 1,
  disgust: 1,
  surprise: 2,
  unknown: 0,
};

const ResultPage = () => {
  const [results, setResults] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const stored = localStorage.getItem("results");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setResults(parsed);
      } catch (e) {
        console.error("Error parsing stored results", e);
        setResults(null);
      }
    }
  }, []);

  const handleBack = () => {
    navigate("/record");
  };

  if (!results) {
    return (
      <>
        <Navbar />
        <h2 style={{ textAlign: "center", marginTop: "50px" }}>
          Loading results...
        </h2>
      </>
    );
  }

  const faceScore =
    results.emotional_intelligence?.emotional_intelligence_score ?? 0;
  const faceEmotion =
    results.emotional_intelligence?.detected_emotion ?? "unknown";
  const voiceEmotion = results.voice_analysis?.detected_emotion ?? "unknown";
  const voiceScore = results.voice_analysis?.voice_ei_score ?? 0;
  const finalScore = results.final_ei_score ?? 0;

  const frameData = results.face_frame_data ?? [];
  const chartData = frameData.map((frame, index) => ({
    name: `Frame ${index + 1}`,
    emotion: emotionMap[frame.emotion] ?? 0,
  }));

  const suggestion =
    finalScore >= 0.8
      ? "Excellent emotional intelligence! Keep it up."
      : finalScore >= 0.6
      ? "Good job! You can refine your emotional expression further."
      : finalScore >= 0.4
      ? "Consider practicing positive emotional responses and tone."
      : "Work on expressing your emotions clearly.";

  return (
    <>
      <Navbar />
      <div style={{ padding: "20px", textAlign: "center" }}>
        <h2>Analysis Results</h2>
        <p>
          <strong>Detected Emotion (Face):</strong> {faceEmotion}
        </p>
        <p>
          <strong>EI Score (Face):</strong> {faceScore.toFixed(2)}
        </p>
        <p>
          <strong>Detected Emotion (Voice):</strong> {voiceEmotion}
        </p>
        <p>
          <strong>EI Score (Voice):</strong> {voiceScore.toFixed(2)}
        </p>
        <p>
          <strong>Final Emotional Intelligence Score:</strong>{" "}
          {finalScore.toFixed(2)}
        </p>

        <h3>Suggestions</h3>
        <p>{suggestion}</p>

        <div style={{ width: "100%", height: 300, marginTop: "30px" }}>
          <ResponsiveContainer>
            <LineChart data={chartData}>
              <CartesianGrid stroke="#ccc" />
              <XAxis dataKey="name" />
              <YAxis domain={[0, 3]} ticks={[0, 1, 2, 3]} />
              <Tooltip />
              <Line
                type="monotone"
                dataKey="emotion"
                stroke="#10b981"
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <button onClick={handleBack} style={backButtonStyle}>
          Record Again
        </button>
      </div>
    </>
  );
};

const backButtonStyle = {
  marginTop: "30px",
  padding: "10px 20px",
  fontSize: "16px",
  backgroundColor: "#3b82f6",
  color: "white",
  border: "none",
  borderRadius: "6px",
  cursor: "pointer",
};

export default ResultPage;
