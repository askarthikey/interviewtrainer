// src/components/VideoRecorder.js
import React, { useRef, useState } from "react";
import Navbar from "./Navbar";
import { useNavigate } from "react-router-dom";

const VideoRecorder = () => {
  const videoRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const [recording, setRecording] = useState(false);
  const recordedChunks = useRef([]);
  const navigate = useNavigate();

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true,
    });
    videoRef.current.srcObject = stream;
    videoRef.current.muted = true;
    videoRef.current.volume = 0;
    videoRef.current.setAttribute("muted", true);

    mediaRecorderRef.current = new MediaRecorder(stream, {
      mimeType: "video/webm",
    });

    mediaRecorderRef.current.ondataavailable = (event) => {
      if (event.data.size > 0) {
        recordedChunks.current.push(event.data);
      }
    };

    mediaRecorderRef.current.onstop = handleStop;

    mediaRecorderRef.current.start();
    setRecording(true);
  };

  const stopRecording = () => {
    mediaRecorderRef.current.stop();
    videoRef.current.srcObject.getTracks().forEach((track) => track.stop());
    setRecording(false);
  };

  const handleStop = async () => {
    const blob = new Blob(recordedChunks.current, { type: "video/webm" });
    const formData = new FormData();
    formData.append("video", blob, "interview.mp4");

    try {
      const response = await fetch("http://localhost:5001/analyze", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      localStorage.setItem("results", JSON.stringify(data.results));
      navigate("/results");
    } catch (err) {
      console.error("Error sending video:", err);
    }
  };

  return (
    <>
      <Navbar />
      <div style={{ textAlign: "center", marginTop: "20px" }}>
        <h2>Record Your Interview</h2>
        <video
          ref={videoRef}
          autoPlay
          playsInline
          style={{ width: "640px", height: "480px", border: "2px solid black" }}
        />
        <div style={{ marginTop: "20px" }}>
          {!recording ? (
            <button onClick={startRecording} style={buttonStyle}>
              Start Recording
            </button>
          ) : (
            <button
              onClick={stopRecording}
              style={{ ...buttonStyle, backgroundColor: "#ef4444" }}
            >
              Stop and Analyze
            </button>
          )}
        </div>
      </div>
    </>
  );
};

const buttonStyle = {
  padding: "12px 25px",
  fontSize: "16px",
  fontWeight: "bold",
  backgroundColor: "#10b981",
  color: "white",
  border: "none",
  borderRadius: "6px",
  cursor: "pointer",
};

export default VideoRecorder;
