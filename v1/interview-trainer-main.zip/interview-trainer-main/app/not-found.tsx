export default function NotFound() {
  return (
    <div className="min-h-screen flex justify-center items-center">
      <div className="text-red-500 text-lg">Not Found</div>
    </div>
  );
}
