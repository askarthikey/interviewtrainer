import { NewVerificationForm } from '@/components/auth/new-verification-form'
import React from 'react'

const NewVerificationPage = () => {
  return (
    <div>
      <NewVerificationForm/>
    </div>
  )
}

export default NewVerificationPage
