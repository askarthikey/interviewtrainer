import { NewPasswordForm } from "@/components/auth/new-password-form";

const NewPasswordPage = () => {
  return ( 
    <NewPasswordForm />
   );
}
 
export default NewPasswordPage;