import React from 'react'

const page = () => {
  return (
    <div>
      vastadha raadha
    </div>
  )
}

export default page
