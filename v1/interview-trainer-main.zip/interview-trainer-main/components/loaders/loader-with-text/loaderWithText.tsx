import React from "react";

const LoaderWithText = () => {
  return (
    <div className="flex flex-col items-center justify-center space-y-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      <p className="text-lg font-medium text-muted-foreground">
        Loading interview...
      </p>
    </div>
  );
};

export default LoaderWithText;